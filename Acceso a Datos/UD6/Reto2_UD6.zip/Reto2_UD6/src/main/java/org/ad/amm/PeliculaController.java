package org.ad.amm;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PeliculaController {
	RepositorioPelicula repositorioPelicula;
	public PeliculaController(RepositorioPelicula repositorioPelicula) {
		this.repositorioPelicula = repositorioPelicula;
		this.repositorioPelicula.save(new Pelicula("drama", "Los lunes al Sol", "Kaspersky"));
		this.repositorioPelicula.save(new Pelicula("romantica", "Titanic", "James Cameron"));
	}
	@PostMapping("/peliculas")
	Pelicula postPelicula(@RequestBody Pelicula peli) {
		repositorioPelicula.save(peli);
		return peli;
	}
	
	@GetMapping("/peliculas")
	List<Pelicula> getAll() {
		return (List<Pelicula>) repositorioPelicula.findAll();
	}
	
	@GetMapping("/peliculas/{id}")
	Pelicula getOne(@PathVariable(name = "id") Long id) {
		return repositorioPelicula.findById(id).orElse(null);
	}
}
