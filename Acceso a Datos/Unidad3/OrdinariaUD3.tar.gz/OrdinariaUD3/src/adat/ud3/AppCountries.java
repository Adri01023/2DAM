package adat.ud3;

import java.util.List;



import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class AppCountries {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("naciones");
		EntityManager em = emf.createEntityManager();
		try {
			//em.getTransaction().begin();
			List<Continent> continents = em.createQuery("SELECT c FROM Continent c",Continent.class).getResultList();
			
			System.out.println("\nContinentes:");
			for (Continent continent : continents) {
				System.out.println(continent);
				for (Region region : continent.getRegions()) {
					System.out.println("\t" + region);
					for (Country country : region.getCountries()) {
						System.out.println("\t\t" + country.getName());
						for (Language language : country.getLanguages()) {
							System.out.println("\t\t\t" + language);
						}
					}
				}
				
			}
			//em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			em.close();
		}
	}

}
