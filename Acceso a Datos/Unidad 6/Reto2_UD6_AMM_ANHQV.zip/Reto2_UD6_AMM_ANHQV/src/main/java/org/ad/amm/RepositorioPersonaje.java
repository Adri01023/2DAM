package org.ad.amm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioPersonaje extends JpaRepository<Personaje, Long>{

}

/*
{
"nombre": "Juan Cuesta",
"domicilio": "Desengaño 21, 2ºA",
"hobbie": "Hacer maquetas",
"profesion": "Profesor",
"haSidoPresidente": true
}
*/

/*
{
  "nombre": "Paloma Cuesta",
  "domicilio": "Desengaño 21, 2ºA",
  "hobbie": "Cotillear",
  "profesion": "Ama de casa",
  "haSidoPresidente": true
}
*/

/*
{
"nombre": "La Hierbas",
"domicilio": "Desengaño 21, 2ºB",
"hobbie": "Fumar de la pipa",
"profesion": "Enfermera",
"haSidoPresidente": false
}
*/