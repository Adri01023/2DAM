package org.ad.amm;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/personajes")
public class PersonajeController {
	RepositorioPersonaje repositorioPersonaje;
	public PersonajeController(RepositorioPersonaje repo) {
		repositorioPersonaje = repo;
	}
	
	@GetMapping // GET TODOS
	ResponseEntity<List<Personaje>> getAll() {
		return ResponseEntity.ok(repositorioPersonaje.findAll()); // código 200
	}
	
	@GetMapping("/{id}") // POR ID
	ResponseEntity<Personaje> getByID(@PathVariable(name = "id") Long id) {
		Optional<Personaje> vecino = repositorioPersonaje.findById(id);
		if (vecino.isEmpty()) {
			return ResponseEntity.notFound().build(); // código 404
		} else {
			return ResponseEntity.ok(vecino.get());
		}
	}
	
	@PostMapping // POST
	ResponseEntity<Personaje> crearPersonaje(@RequestBody Personaje vecino) {
		Personaje creado = repositorioPersonaje.save(vecino);
		return ResponseEntity.status(HttpStatus.CREATED).body(creado); // código 201
	}
	
	@PutMapping("/{id}") // PUT
	ResponseEntity<Personaje> actualizar(@PathVariable(name = "id") Long id, @RequestBody Personaje cambio) {
		if (!repositorioPersonaje.existsById(id)) {
			return ResponseEntity.notFound().build();
		} else {
			cambio.setId(id);
			Personaje actualizado = repositorioPersonaje.save(cambio);
			return ResponseEntity.ok(actualizado);
		}
	}
	
	@PatchMapping("/{id}")
	ResponseEntity<Personaje> actualizarParcial(@PathVariable(name = "id") Long id, @RequestBody Personaje cambioParcial) {
		Optional<Personaje> vecinoOpt = repositorioPersonaje.findById(id);
		if (vecinoOpt.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		Personaje vecino = vecinoOpt.get();
		
		if (cambioParcial.getNombre() != null) {
			vecino.setNombre(cambioParcial.getNombre());
		}
		
		if (cambioParcial.getProfesion() != null) {
			vecino.setProfesion(cambioParcial.getProfesion());
		}
		
		if (cambioParcial.getHobbie() != null) {
			vecino.setHobbie(cambioParcial.getHobbie());
		}
		
		if (cambioParcial.getDomicilio() != null) {
			vecino.setDomicilio(cambioParcial.getDomicilio());
		}
		
		if (cambioParcial.getHaSidoPresidente() != null) {
			vecino.setHaSidoPresidente(cambioParcial.getHaSidoPresidente());
		}
		
		Personaje vecinoCambiado = repositorioPersonaje.save(vecino);
		return ResponseEntity.ok(vecinoCambiado);
	}
	
	@DeleteMapping("/{id}")
	ResponseEntity<Personaje> borrado(@PathVariable(name = "id") Long id) {
		if (!repositorioPersonaje.existsById(id)) {
			return ResponseEntity.notFound().build();
		}
		
		repositorioPersonaje.deleteById(id);
		return ResponseEntity.noContent().build(); // código 204
	}
}
