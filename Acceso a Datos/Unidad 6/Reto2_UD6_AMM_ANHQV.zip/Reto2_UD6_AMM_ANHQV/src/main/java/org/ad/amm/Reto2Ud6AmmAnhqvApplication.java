package org.ad.amm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reto2Ud6AmmAnhqvApplication {

	public static void main(String[] args) {
		SpringApplication.run(Reto2Ud6AmmAnhqvApplication.class, args);
	}

}
