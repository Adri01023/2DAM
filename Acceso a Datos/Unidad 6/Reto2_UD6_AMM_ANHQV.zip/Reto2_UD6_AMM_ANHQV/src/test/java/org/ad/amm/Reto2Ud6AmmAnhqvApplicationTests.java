package org.ad.amm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto2Ud6AmmAnhqvApplicationTests {

	@Test
	void contextLoads() {
	}

}
