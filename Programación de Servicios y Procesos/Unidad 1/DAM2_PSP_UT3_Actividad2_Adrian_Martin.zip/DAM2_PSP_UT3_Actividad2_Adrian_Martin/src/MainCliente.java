import Cliente.ClienteUI;

/**
 * Clase principal para iniciar la aplicación cliente de chat. IMPORTANTE INICIAR SERVIDOR ANTES.
 * Para comprobar el funcionamiento simultáneo de varios clientes, iniciar varias instancias de esta clase.
 */

public class MainCliente {
    public static void main(String[] args) {
        ClienteUI clienteUI = new ClienteUI();
        clienteUI.setVisible(true);
    }
}
