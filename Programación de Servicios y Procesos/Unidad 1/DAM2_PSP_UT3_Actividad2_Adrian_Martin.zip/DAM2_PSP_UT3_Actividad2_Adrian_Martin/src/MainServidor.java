import Servidor.ServidorChat;

/**
 * Clase principal para iniciar el servidor de chat.
 * Debe iniciarse antes que los clientes para permitir conexiones.
 */

public class MainServidor {
    public static void main(String[] args) {
        ServidorChat servidorChat = new ServidorChat();
        servidorChat.iniciarServidor();
    }
}