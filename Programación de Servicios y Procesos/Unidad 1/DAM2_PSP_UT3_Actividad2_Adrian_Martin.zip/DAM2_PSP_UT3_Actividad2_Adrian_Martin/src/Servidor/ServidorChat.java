package Servidor;

import Cliente.HiloCliente;
import Cliente.MensajeChat;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class ServidorChat {
    public static final int PUERTO = 5555; // Puerto por defecto del servidor
    private int contadorClientes = 1; // Contador para asignar IDs únicos a los clientes
    private Map<Integer, HiloCliente> clientesConectados = new HashMap<>(); // Mapa de clientes conectados
    private Map<String, Integer> mapaClientes = new HashMap<>(); // Mapa de nombres de clientes y sus IDs

    /**
     * Inicia el servidor de chat, aceptando conexiones de clientes, creando un hilo para cada uno
     * y asignando su correspondiente ID. (Al inicio se asigna el ID 0 al usuario "TODOS" para mensajes globales)
     */

    public void iniciarServidor() {
        mapaClientes.put("TODOS", 0);
        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            System.out.println("Servidor de chat iniciado en el puerto " + PUERTO);
            while (true) {
                Socket socketCliente = serverSocket.accept();
                HiloCliente hiloCliente = new HiloCliente(contadorClientes, socketCliente, this);
                clientesConectados.put(contadorClientes, hiloCliente);
                hiloCliente.start();
                System.out.println("Cliente conectado con ID: " + contadorClientes);
                contadorClientes++;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Envía la lista actualizada de clientes a todos los clientes conectados.
     */

    public void enviarListaClientes() {
        for (HiloCliente hiloCliente : clientesConectados.values()) {
            hiloCliente.enviarListaClientes(new HashMap<>(mapaClientes));
        }
    }

    /**
     * Reenvía un mensaje recibido a su destino correspondiente.
     * Si este es 0, se envía a todos los clientes conectados excepto al origen.
     * @param mensaje Mensaje a reenviar
     */

    public void reenviarMensaje(MensajeChat mensaje) {
        if (mensaje.getIdDestino() == 0) {
            for (HiloCliente hiloCliente : clientesConectados.values()) {
                if (hiloCliente.getIdCliente() != mensaje.getIdOrigen()) {
                    hiloCliente.enviarMensaje(mensaje);
                }
            }
        } else {
            HiloCliente hiloDestino = clientesConectados.get(mensaje.getIdDestino());
            if (hiloDestino != null) {
                hiloDestino.enviarMensaje(mensaje);
            }
        }
    }

    /**
     * Registra un nuevo cliente en el mapa de clientes y envía la lista actualizada a todos los clientes.
     * @param nombre Nombre del cliente
     * @param id ID del cliente
     */

    public synchronized void registrarCliente(String nombre, int id) {
        mapaClientes.put(nombre, id);
        enviarListaClientes();
    }
}