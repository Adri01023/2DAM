package Cliente;

import java.io.Serializable;

public class MensajeChat implements Serializable {
    int idOrigen;
    int idDestino;
    String usuarioOrigen;
    String mensaje;

    /**
     * POJO que representa un mensaje de chat.
     * @param origen ID del usuario que envia el mensaje
     * @param destino ID del usuario que recibe el mensaje
     * @param usuario Nombre del usuario que envia el mensaje
     * @param mensaje Contenido del mensaje
     */

    public MensajeChat(int origen, int destino, String usuario, String mensaje) {
        this.idOrigen = origen;
        this.idDestino = destino;
        this.usuarioOrigen = usuario;
        this.mensaje = mensaje;
    }

    public int getIdOrigen() {
        return idOrigen;
    }

    public int getIdDestino() {
        return idDestino;
    }

    public String getUsuarioOrigen() {
        return usuarioOrigen;
    }

    public String getMensaje() {
        return mensaje;
    }
}
