package Cliente;

import Servidor.ServidorChat;

import java.awt.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;

public class HiloCliente extends Thread{
    private int idCliente;
    private Socket socket;
    private String nombreCliente;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;
    private ServidorChat servidorChat;

    /**
     * Constructor de la clase HiloCliente.
     * @param idCliente ID del cliente asociado a este hilo
     * @param socket Socket de comunicación con el cliente
     * @param servidorChat Referencia al servidor de chat para reenviar mensajes y registrar clientes
     */

    public HiloCliente(int idCliente, Socket socket, ServidorChat servidorChat) {
        this.idCliente = idCliente;
        this.socket = socket;
        this.servidorChat = servidorChat;
        try {
            salida = new ObjectOutputStream(socket.getOutputStream());
            entrada = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public int getIdCliente() {
        return idCliente;
    }

    /**
     * Cuando se inicia el hilo este le manda su id al cliente, luego espera a que el cliente le envie su nombre
     * y lo registra en el servidor. Luego entra en un bucle infinito esperando mensajes
     * del cliente para reenviarlos a los demas clientes.
     */

    @Override
    public void run() {
        try {
            salida.writeInt(idCliente);
            salida.flush();

            Object obj = entrada.readObject();
            nombreCliente = (String) obj;
            servidorChat.registrarCliente(nombreCliente, idCliente);
            while (true) {
                Object recibido = entrada.readObject();
                if (recibido instanceof MensajeChat mensaje) {
                    servidorChat.reenviarMensaje(mensaje);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Envía un mensaje al cliente asociado a este hilo.
     * @param mensaje instancia de MensajeChat a enviar
     */

    public void enviarMensaje(MensajeChat mensaje) {
        try {
            salida.writeObject(mensaje);
            salida.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Envía la lista de clientes conectados al cliente asociado a este hilo.
     * @param listaUsuarios mapa con los nombres de usuario y sus IDs
     */

    public void enviarListaClientes(HashMap<String, Integer> listaUsuarios) {
        try {
            salida.writeObject(listaUsuarios);
            salida.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

