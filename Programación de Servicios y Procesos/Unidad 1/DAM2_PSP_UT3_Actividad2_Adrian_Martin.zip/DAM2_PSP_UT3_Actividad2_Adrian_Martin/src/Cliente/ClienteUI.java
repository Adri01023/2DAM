package Cliente;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;

public class ClienteUI extends JFrame {

    private static HashMap<String, Integer> mapa_clientes = new HashMap<>();

    private JTextArea areaMensajes;
    private JTextField campoMensaje;
    private JComboBox<String> comboDestinatarios;
    private JButton botonEnviar;

    private Socket socket;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;

    private int idCliente;
    private String nombre;

    /**
     * Constructor que implementa VentanaConfiguracion para obtener los datos
     * necesarios para la conexión con el servidor y llama a los métodos para
     * crear la interfaz y escuchar mensajes.
     */

    public ClienteUI() {
        VentanaConfiguracion vc = new VentanaConfiguracion(this);
        this.nombre = vc.getUsuario();
        try {
            conectar(vc.getHost(), vc.getPuerto());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        crearInterfaz();
        escucharMensajes();
    }

    /**
     * Establece la conexión con el servidor, recibiendo de este el id que le corresponde
     * y mandando el nombre que le ha sido asignado.
     */

    private void conectar(String ip, int puerto) {
        try {
            socket = new Socket(ip, puerto);
            salida = new ObjectOutputStream(socket.getOutputStream());
            entrada = new ObjectInputStream(socket.getInputStream());
            idCliente = entrada.readInt();
            salida.writeObject(nombre);
            salida.flush();
        } catch (IOException e) {
            System.out.println("Error al conectar con el servidor");
            System.exit(0);
            throw new RuntimeException(e);
        }
    }

    /**
     * Crea la interfaz gráfica.
     */

    private void crearInterfaz() {
        setTitle("Chat - " + nombre);
        setSize(500, 400);

        areaMensajes = new JTextArea();
        areaMensajes.setEditable(false);

        campoMensaje = new JTextField();
        comboDestinatarios = new JComboBox<>();

        botonEnviar = new JButton("Enviar");
        botonEnviar.addActionListener(e -> enviarMensaje());

        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.add(comboDestinatarios, BorderLayout.WEST);
        panelInferior.add(campoMensaje, BorderLayout.CENTER);
        panelInferior.add(botonEnviar, BorderLayout.EAST);

        add(new JScrollPane(areaMensajes), BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);

        setVisible(true);
    }

    /**
     * En caso de que el campo de mensaje no esté vacío, crea un objeto MensajeChat
     * con el contenido del mensaje, el idOrigen, el idDestino y el nombre del origen y lo envía al servidor.
     * Extrayendo el idDestino del mapa de clientes según el nombre seleccionado en el combobox.
     */

    private void enviarMensaje() {
        String texto = campoMensaje.getText().trim();
        if (texto.isEmpty()) return;
        try {
            int idDestino = mapa_clientes.get(comboDestinatarios.getSelectedItem().toString());

            MensajeChat mensaje = new MensajeChat(idCliente, idDestino, nombre, texto);
            salida.writeObject(mensaje);
            salida.flush();

            areaMensajes.append("Mensaje a " + comboDestinatarios.getSelectedItem().toString() + " -> " + texto + "\n");
            campoMensaje.setText("");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Escucha mensajes entrantes sin bloquear la interfaz, diferenciando entre mensajes de tipo
     * MensajeChat (en este caso actualiza el area de mensajes) o bien el mapa que contiene los
     * nombres e ids de los clientes (en este caso actualiza el combobox).
     */

    private void escucharMensajes() {
        new Thread(() -> {
            try {
                while (true) {
                    Object obj = entrada.readObject();
                    if (obj instanceof MensajeChat mensaje) {
                        SwingUtilities.invokeLater(() -> {
                            areaMensajes.append(
                                    "Mensaje de " + mensaje.getUsuarioOrigen() + " -> " + mensaje.getMensaje() + "\n"
                            );
                        });
                    }

                    if (obj instanceof HashMap<?, ?> nombres) {
                        SwingUtilities.invokeLater(() -> {
                            mapa_clientes = (HashMap<String, Integer>) nombres;
                            comboDestinatarios.removeAllItems();
                            for (Object nombre : nombres.keySet()) {
                                if (!nombre.equals(this.nombre)) {
                                    comboDestinatarios.addItem(nombre.toString());
                                }
                            }
                        });
                    }
                }
            } catch (Exception e) {
                areaMensajes.append("Desconectado del servidor\n");
                e.printStackTrace();
            }
        }).start();
    }
}
