package Actividad1_2;
import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;


public class LanzadorProcesos {
    private void lanzaRandoms() {
        ProcessBuilder pb;
        Process process;
        String classname = "Actividad1_2.GeneraRandoms";
        String currentpath = System.getProperty("user.dir");
        String classpath = currentpath + "/out/production/ComunicacionProcesos/";
        try {
            pb = new ProcessBuilder("java", "-cp", classpath, classname);
            process = pb.start();
            process.waitFor();
            File archivo = new File("numeros.txt");
            FileInputStream fis = new FileInputStream(archivo);
            System.out.print(fis.read());
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LanzadorProcesos lanzador = new LanzadorProcesos();
        String linea = "";
        int veces;
        System.out.print("Introduce caracteres: ");
        while (!linea.equalsIgnoreCase("fin")) {
            System.out.println();
            linea = sc.nextLine();
            if (!linea.equalsIgnoreCase("fin")) {
                veces = linea.length();
                for (int i = 0; i < veces; i++) {
                    lanzador.lanzaRandoms();
                }
            }
        }
    }
}
