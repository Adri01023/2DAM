package com.example.dam2_pmm_ut2_actividad3_adrian_martin.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dam2_pmm_ut2_actividad3_adrian_martin.R;
import com.example.dam2_pmm_ut2_actividad3_adrian_martin.data.Frase;

import java.util.List;

public class FrasesAdapter extends RecyclerView.Adapter<FrasesAdapter.FrasesViewHolder> {
    private List<Frase> frases;
    public FrasesAdapter(List<Frase> frases) {this.frases = frases;}

    @NonNull
    @Override
    public FrasesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_frase, parent, false);
        return new FrasesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FrasesAdapter.FrasesViewHolder holder, int position) {
        Frase frase = frases.get(position);
        holder.autor.setText(frase.getAutor());
        holder.frase.setText(frase.getFrase());
    }

    @Override
    public int getItemCount() {
        return frases.size();
    }

    public void setFrases(List<Frase> frases) {
        this.frases = frases;
        notifyDataSetChanged();
    }

    public static class FrasesViewHolder extends RecyclerView.ViewHolder {
        TextView autor, frase;
        public FrasesViewHolder(@NonNull View itemView) {
            super(itemView);
            autor = itemView.findViewById(R.id.textoAutor);
            frase = itemView.findViewById(R.id.textoFrase);
        }
    }
}
