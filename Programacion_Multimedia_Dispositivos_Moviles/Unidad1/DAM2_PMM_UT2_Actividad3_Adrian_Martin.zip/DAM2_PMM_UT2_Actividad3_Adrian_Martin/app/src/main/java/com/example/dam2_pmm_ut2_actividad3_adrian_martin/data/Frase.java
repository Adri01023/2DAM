package com.example.dam2_pmm_ut2_actividad3_adrian_martin.data;

public class Frase {
    private String autor, frase;

    public Frase(String autor, String frase) {
        this.autor = autor;
        this.frase = frase;
    }

    public String getAutor() {
        return autor;
    }

    public String getFrase() {
        return frase;
    }
}
