package com.example.dam2_pmm_ut2_actividad3_adrian_martin.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class FraseDAO extends FraseDBHelper {
    private Context contexto;
    public FraseDAO(@Nullable Context context) {
        super(context);
        contexto = context;
    }

    public void insertarFrase(String autor, String frase) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contenido = new ContentValues();
        contenido.put("autor",autor);
        contenido.put("frase",frase);
        db.insert(DATABASE_TABLA, null, contenido);
    }

    public ArrayList<Frase> getListaFrases() {
        ArrayList<Frase> frases = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Frase frase;
        Cursor cursorFrase = db.rawQuery("SELECT * FROM " + DATABASE_TABLA, null);
        if (cursorFrase.moveToFirst()) {
            do {
                String autor = cursorFrase.getString(0);
                String texto_frase = cursorFrase.getString(1);
                frase = new Frase(autor, texto_frase);
                frases.add(frase);
            } while (cursorFrase.moveToNext());
        }
        if (frases.isEmpty()) {

        }
        return frases;
    }

    public void eliminarFrases() {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM " + DATABASE_TABLA);
    }
}
