package com.example.dam2_pmm_ut2_actividad3_adrian_martin;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dam2_pmm_ut2_actividad3_adrian_martin.data.FraseDAO;
import com.example.dam2_pmm_ut2_actividad3_adrian_martin.data.FraseDBHelper;
import com.example.dam2_pmm_ut2_actividad3_adrian_martin.ui.FrasesAdapter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private FraseDAO frases_db = new FraseDAO(this);
    private FrasesAdapter adapter;
    private final String URL_JSON = "https://zenquotes.io/api/random";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        try (FraseDBHelper dbAyudante = new FraseDBHelper(this)) {
            SQLiteDatabase db = dbAyudante.getWritableDatabase();
            if (db != null) {
                Toast.makeText(this, "Base de Datos Creada", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No se ha podido crear la BD", Toast.LENGTH_SHORT).show();
            }
        }
        setContentView(R.layout.activity_main);
        RecyclerView recyclerViewFrases = findViewById(R.id.recyclerViewFrases);
        adapter = new FrasesAdapter(frases_db.getListaFrases());
        recyclerViewFrases.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewFrases.setAdapter(adapter);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void descargarFrase(View view) {
        RecyclerView recyclerViewFrases = findViewById(R.id.recyclerViewFrases);
        adapter = new FrasesAdapter(frases_db.getListaFrases());
        recyclerViewFrases.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewFrases.setAdapter(adapter);
        new Thread(() -> {
            try {
                URL url = new URL(URL_JSON);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.connect();
                int code = conn.getResponseCode();
                System.out.println("Codigo: " + code);
                if (code == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();
                    System.out.println(response);
                    JSONArray jsonarray = new JSONArray(response.toString());
                    for (int i = 0; i < jsonarray.length(); i++) {
                        JSONObject objeto = jsonarray.getJSONObject(i);
                        frases_db.insertarFrase(objeto.getString("a"), objeto.getString("q"));
                    }
                } else if (code == 429) {
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Demasiadas peticiones, espera un momento...", Toast.LENGTH_SHORT).show();
                    });
                }
                runOnUiThread(() -> adapter.setFrases(frases_db.getListaFrases()));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).start();
    }

    public void ocultaroMostrar(View view) {
        RecyclerView recyclerViewFrases = findViewById(R.id.recyclerViewFrases);
        Button boton = view.findViewById(R.id.botonOcultarMostrar);
        int visibilidad = recyclerViewFrases.getVisibility();
        if (visibilidad == View.VISIBLE) {
            recyclerViewFrases.setVisibility(View.INVISIBLE);
            boton.setText(R.string.mostrar_frases);
        } else {
            recyclerViewFrases.setVisibility(View.VISIBLE);
            boton.setText(R.string.ocultar_frases);
        }
    }

    public void eliminarFrases(View view) {
        frases_db.eliminarFrases();
        adapter.setFrases(frases_db.getListaFrases());
    }
}