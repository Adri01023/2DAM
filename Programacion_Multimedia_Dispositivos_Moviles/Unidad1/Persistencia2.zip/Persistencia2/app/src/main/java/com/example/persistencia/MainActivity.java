package com.example.persistencia;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.persistencia.data.Contactos;
import com.example.persistencia.data.DAOContactos;
import com.example.persistencia.data.DBAyudante;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText txtNombre;
    EditText txtTel;
    EditText txtCorreo;
    RecyclerView listaContactos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button basedeDatos = findViewById(R.id.botonCrear);
        basedeDatos.setOnClickListener(v -> {
            try (DBAyudante dbAyudante = new DBAyudante(this)) {
                SQLiteDatabase db = dbAyudante.getWritableDatabase();
                if (db != null) {
                    Toast.makeText(this, "Base de Datos Creada", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "No se ha podido crear la BD", Toast.LENGTH_SHORT).show();
                }
            }
        });
        txtNombre = findViewById(R.id.editTextNombre);
        txtTel = findViewById(R.id.editTextTel);
        txtCorreo = findViewById(R.id.editTextCorreo);
        Button botonInsertar = findViewById(R.id.botonInsertar);

        botonInsertar.setOnClickListener(v -> {
            try (DAOContactos contacto = new DAOContactos(this)) {
                contacto.insertarContacto(
                        txtNombre.getText().toString(),
                        txtTel.getText().toString(),
                        txtCorreo.getText().toString());
            }
            limpiar();
            mostrarContactos();
        });
        listaContactos = findViewById(R.id.listaContactos);
        listaContactos.setLayoutManager(new LinearLayoutManager(this));
        mostrarContactos();
    }

    private void limpiar() {
        txtNombre.setText("");
        txtTel.setText("");
        txtCorreo.setText("");
    }
    private void mostrarContactos() {
        try (DAOContactos contacto = new DAOContactos(this)){
            List<Contactos> arrayContactos = new ArrayList<>();
            ListaContactosAdapter adapter = new ListaContactosAdapter(contacto.mostrarContactos());
            listaContactos.setAdapter(adapter);
        }
    }
}