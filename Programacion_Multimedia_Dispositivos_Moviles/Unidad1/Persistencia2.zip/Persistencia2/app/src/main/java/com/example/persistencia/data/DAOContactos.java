package com.example.persistencia.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DAOContactos extends DBAyudante {

    private Context contexto;
    public DAOContactos(@Nullable Context context) {
        super(context);
        contexto = context;
    }

    public void insertarContacto(String nombre, String telefono, String correo) {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues contenido = new ContentValues();
            contenido.put("nombre", nombre);
            contenido.put("telefono", telefono);
            contenido.put("correo", correo);
            db.insert(DATABASE_TABLA, null, contenido);
    }

    public ArrayList<Contactos> mostrarContactos() {
        ArrayList<Contactos> listaContactos = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Contactos contacto;
        Cursor cursorContacto = db.rawQuery("SELECT * FROM " + DATABASE_TABLA, null);
        if (cursorContacto.moveToFirst()) {
            do {
                contacto = new Contactos();
                contacto.setId(cursorContacto.getInt(0));
                contacto.setNombre(cursorContacto.getString(1));
                contacto.setTelefono(cursorContacto.getString(2));
                contacto.setCorreo_electronico(cursorContacto.getString(3));
                listaContactos.add(contacto);
            } while (cursorContacto.moveToNext());
        }
        return listaContactos;
    }
}
