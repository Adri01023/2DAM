package com.example.http;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.http.databinding.FragmentHomeBinding;
import com.example.http.posts.Post;
import com.example.http.posts.PostAdapter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding; // HACER buildFeatures en build.kts
    private PostAdapter adapter;
    private List<Post> postList = new ArrayList<>();
    private final String URL_JSON = "https://jsonplaceholder.typicode.com/posts";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        adapter = new PostAdapter(postList);
        binding.recycledviewPost.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recycledviewPost.setAdapter(adapter);
        binding.button.setOnClickListener(v -> sendGetRequest());
        binding.buttonPost.setOnClickListener(v -> sendPostRequest());
        // Inflate the layout for this fragment
        return binding.getRoot();
    }
/*
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Button botonGet = view.findViewById(R.id.button);
        botonGet.setOnClickListener(v-> sendGetRequest());
    }*/

    private void sendGetRequest() {
        new Thread(() -> {
           List<Post> fetchedPosts = new ArrayList<>();
           try {
               URL url = new URL(URL_JSON);
               HttpURLConnection conn = (HttpURLConnection) url.openConnection();
               conn.setRequestMethod("GET");
               conn.setConnectTimeout(5000);
               conn.setReadTimeout(5000);
               conn.connect();
               System.out.println("CONEXION ABIERTA");
               int code = conn.getResponseCode();
               System.out.println("Codigo: " + code);
               if (code == HttpURLConnection.HTTP_OK) {
                   System.out.println("Bien peña");
                   BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                   StringBuilder response = new StringBuilder();
                   String linea;
                   while ((linea = reader.readLine()) != null) {
                       response.append(linea);
                   }
                   reader.close();
                   System.out.println(response);
                   JSONArray jsonarray = new JSONArray(response.toString());
                   for (int i = 0; i < jsonarray.length(); i++) {
                       JSONObject objeto = jsonarray.getJSONObject(i);
                       Post post = new Post(objeto.getInt("userId"), objeto.getInt("id"), objeto.getString("title"), objeto.getString("body"));
                       fetchedPosts.add(post);
                   }
               }
               requireActivity().runOnUiThread(() -> adapter.setPost(fetchedPosts));

           } catch (Exception e) {
               throw new RuntimeException(e);
           }
        }).start();
    }

    private void sendPostRequest() {
        new Thread(() -> {
            List<Post> fetchedPosts = new ArrayList<>();
            try {
                URL url = new URL(URL_JSON);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                String jsonBody = "{\"userId\": 99, \"Id\": 1, \"title\": \"Nuevo título\", \"body\": \"Contenido del post\"}";
                conn.connect();
                System.out.println("CONEXION ABIERTA");
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonBody.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }
                int code = conn.getResponseCode();
                System.out.println("Codigo: " + code);
                if (code == HttpURLConnection.HTTP_CREATED) {
                    System.out.println("Bien peña");
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    response.append("[");
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    response.append("]");
                    reader.close();
                    System.out.println(response);
                    JSONArray jsonarray = new JSONArray(response.toString());
                    for (int i = 0; i < jsonarray.length(); i++) {
                        JSONObject objeto = jsonarray.getJSONObject(i);
                        Post post = new Post(objeto.getInt("userId"), objeto.getInt("id"), objeto.getString("title"), objeto.getString("body"));
                        fetchedPosts.add(post);
                    }
                } else {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();
                    System.out.println(response);
                    JSONArray jsonarray = new JSONArray(response.toString());
                    for (int i = 0; i < jsonarray.length(); i++) {
                        JSONObject objeto = jsonarray.getJSONObject(i);
                        Post post = new Post(objeto.getInt("userId"), objeto.getInt("id"), objeto.getString("title"), objeto.getString("body"));
                        fetchedPosts.add(post);
                    }
                }
                requireActivity().runOnUiThread(() -> adapter.setPost(fetchedPosts));

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).start();
    }
}