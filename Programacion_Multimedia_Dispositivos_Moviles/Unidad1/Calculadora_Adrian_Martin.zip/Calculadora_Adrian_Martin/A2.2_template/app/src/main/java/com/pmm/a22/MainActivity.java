package com.pmm.a22;

import static com.pmm.a22.R.*;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.pmm.a22.calculator.Calculator;

public class MainActivity extends AppCompatActivity {

    private final Calculator _calculator= new Calculator();

    public TextView textoResultado;
    private String resultado= "";
    private boolean calculado= false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calculator);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(id.tableCalculadora), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        textoResultado = findViewById(id.tvResultado);
    }


    public void operandClick(View view) {

        if (calculado) clearClick(null);
        Button boton = (Button) view;
        String operand= boton.getText().toString();

        // COMPLETAR COMO PARTE DEL EJERCICIO SELECCIONANDO EL OPERANDO
        _calculator.setOperand(operand);

        resultado += operand;

        // COMPLETAR COMO PARTE DEL EJERCICIO ACTUALIZANDO LA PANTALLA DE LA CALCULADORA
        textoResultado.setText(resultado);
    }

    public void operatorClick(View view) {

        Button boton = (Button) view;
        String operador1 = boton.getText().toString();

        if (operador1.equals("=") && !_calculator.isNewOperation()) {
            resultado = _calculator.calculate().toString();
            _calculator.setNewOperation(true);
            _calculator.setOperand(resultado);
        } else {
        // COMPLETAR COMO PARTE DEL EJERCICIO SELECCIONANDO EL OPERADOR
        Calculator.Operators operator= _calculator.seleccionar(operador1);
        _calculator.setOperator(operator);
        resultado+= operator;}

        // COMPLETAR COMO PARTE DEL EJERCICIO ACTUALIZANDO LA PANTALLA DE LA CALCULADORA
        textoResultado.setText(resultado);
    }

    public void clearClick(View view) {

        _calculator.clear();
        calculado= false;
        resultado= "";

        // COMPLETAR COMO PARTE DEL EJERCICIO ACTUALIZANDO LA PANTALLA DE LA CALCULADORA
        textoResultado.setText(resultado);
    }

}